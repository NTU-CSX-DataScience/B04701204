Sys.setlocale(category='LC_ALL', locale='C')
## 詞頻矩陣：TD-IDF

#Create TDM
tdm <- TermDocumentMatrix(corpus2)

#TD-IDF computation
library(Matrix)

N = tdm$ncol
tf <- apply(tdm, 2, sum) # term frequency
idfCal <- function(word_doc){ log2(  N / nnzero(word_doc) ) }
idf <- apply(tdm, 1, idfCal)

doc.tfidf <- as.matrix(tdm)
for(i in 1:nrow(tdm)){
  for(j in 1:ncol(tdm)){
    doc.tfidf[i,j] <- (doc.tfidf[i,j] / tf[j]) * idf[i]
  }
}