library(xml2)
library(rvest)

InaugTestFunction <- function(URL, filename)
{
  html  = html_session(URL)
  transcript <- html %>%
    html_nodes("p") %>%
    html_text()
  transcript = paste(transcript,collapse=" ")
  write.table(transcript, filename)
 }
  