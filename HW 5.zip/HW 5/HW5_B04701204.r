## 網路爬蟲

# Read data
URLs = read.csv("www.presidency.ucsb.edu_5th_Nov_2017.csv")
president = read.csv("president.csv")
URLs = row.names(URLs)
Inaug_URLs = data.frame( president, URLs )

source("InaugTestFunction.R")
id = c(1:58)
URL = as.character(Inaug_URLs$URLs[id])
filename = paste0(id, ".txt")
mapply(InaugTestFunction, 
       URL = URL, filename = filename)    ###為甚麼 function 需要 html_session ?

## 文本清理
rm(list=ls(all.names = TRUE))
library('rvest')
library('NLP')
library('tm')
library('stringr')
filenames <- list.files(getwd(), pattern="*.txt")
files <- lapply(filenames, readLines)
corpus <- Corpus(VectorSource(files))

#Data-Preprocessing: removing punctuation and digits
corpus2 <- tm_map(corpus, removePunctuation)
corpus2 <- tm_map(corpus2, removeNumbers)

#Data-Preprocessing: changing all to lower case
corpus2 <- tm_map(corpus2, tolower)

#Data-Preprocessing: removing stopwords
corpus2 <- tm_map(corpus2, removeWords, stopwords("english"))

#Data-Preprocessing: removing my stopwords
myStopwords <- c("friends", "fellow","citizens","countrymen","my")
corpus2 <- tm_map(corpus2, removeWords, myStopwords)

#Data-Preprocessing: removing single letters
toSpace <- content_transformer(function(x, pattern) {
  return (gsub(pattern, " ", x))})
corpus2 <- tm_map(corpus2, toSpace, "\\b[A-z]\\b{1}")

#Data-Preprocessing: removing whitespaces
corpus2 <- tm_map(corpus2, stripWhitespace)
corpus2


## 詞頻矩陣：TD-IDF

#Create TDM
tdm <- TermDocumentMatrix(corpus2)

#TD-IDF computation
library(Matrix)

N = tdm$ncol
tf <- apply(tdm, 2, sum) # term frequency
idfCal <- function(word_doc){ log2(  N / nnzero(word_doc) ) }
idf <- apply(tdm, 1, idfCal)

doc.tfidf <- as.matrix(tdm)
for(i in 1:nrow(tdm)){
  for(j in 1:ncol(tdm)){
    doc.tfidf[i,j] <- (doc.tfidf[i,j] / tf[j]) * idf[i]
  }
}

#Create TD-IDF: rename columns of TD-IDF
president = read.csv("president.csv")
colnames(doc.tfidf) <- as.vector(unlist(president))  ###為甚麼這裡需要 unlist 再 as.vector ?

## K-Means分群
library(stats)
kmeansOut = kmeans(doc.tfidf, 2, nstart = 20)
