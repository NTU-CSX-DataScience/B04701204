Sys.setlocale(category='LC_ALL', locale='C')
## K-Means分群
source("TextMining.R")
source("TFIDF.R")

library(stats)
library(cluster)

#K-Means：
data = t(doc.tfidf)

#K-Means elbow method：determine optimum numbers of clusters
wss <- 2:58
for (i in 2:58) 
{
  wss[i] <- sum(kmeans(data, centers=i, nstart = 20)$withinss)
}

plot(2:58, wss[2:58], type="b", xlab="Number of Clusters", ylab="Within groups sum of squares")

num_clusters = length(which(unlist(wss) > 0.5))
num_clusters

#K-Means clustering: plot clusters
kmeansOut = kmeans(data, num_clusters, nstart = 20)

testdata = data

data.pca = prcomp(data)
data.kmeans = as.factor(kmeansOut$cluster)

library(devtools)
#install_github("vqv/ggbiplot")
library(ggbiplot)

g <- ggbiplot(data.pca, obs.scale = 1, var.scale = 1, 
              groups = data.kmeans, ellipse = TRUE, 
              circle = TRUE, labels = rownames(data))
g <- g + scale_color_discrete(name = '')
g <- g + theme(legend.direction = 'horizontal', 
               legend.position = 'top')
print(g)
