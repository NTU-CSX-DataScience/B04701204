Sys.setlocale(category='LC_ALL', locale='C')
## K-Means分群
source("TFIDF.R")

library(stats)
library(cluster)

#K-Means algorithm：3 clusters, 20 starting configurations
kmeansOut = kmeans(doc.tfidf, 3, nstart = 10)
clusplot(doc.tfidf, kmeansOut$cluster, color=T, shade=T, labels=2, lines=0)

#K-Means elbow method：determine optimum numbers of clusters
wss <- 2:58
for (i in 2:58) wss[i] <- sum(kmeans(doc.tfidf, centers=i, nstart = 10)$withinss)
plot(2:58, wss[2:58], type="b", xlab="Number of Clusters", ylab="Within groups sum of squares")
