Sys.setlocale(category='LC_ALL', locale='C')
## 網路爬蟲

# Read data
URLs = read.csv("www.presidency.ucsb.edu_5th_Nov_2017.csv")
president = read.csv("president.csv")
URLs = row.names(URLs)
Inaug_URLs = data.frame( president, URLs )

source("InaugTestFunction.R")
id = c(1:58)
URL = as.character(Inaug_URLs$URLs[id])
filename = paste0(id, ".txt")
mapply(InaugTestFunction, 
       URL = URL, filename = filename)    ###為甚麼 function 需要 html_session ?

## 文本清理
rm(list=ls(all.names = TRUE))
library('rvest')
library('NLP')
library('tm')
library('stringr')
filenames <- list.files(getwd(), pattern="*.txt")
files <- lapply(filenames, readLines)
corpus <- Corpus(VectorSource(files))

#Data-Preprocessing: removing punctuation and digits
corpus2 <- tm_map(corpus, removePunctuation)
corpus2 <- tm_map(corpus2, removeNumbers)

#Data-Preprocessing: changing all to lower case
corpus2 <- tm_map(corpus2, tolower)

#Data-Preprocessing: removing stopwords
corpus2 <- tm_map(corpus2, removeWords, stopwords("english"))

#Data-Preprocessing: removing my stopwords
myStopwords <- c("friends", "fellow","citizens","countrymen","my")
corpus2 <- tm_map(corpus2, removeWords, myStopwords)

#Data-Preprocessing: removing single letters
toSpace <- content_transformer(function(x, pattern) {
  return (gsub(pattern, " ", x))})
corpus2 <- tm_map(corpus2, toSpace, "\\b[A-z]\\b{1}")

#Data-Preprocessing: removing whitespaces
corpus2 <- tm_map(corpus2, stripWhitespace)
corpus2